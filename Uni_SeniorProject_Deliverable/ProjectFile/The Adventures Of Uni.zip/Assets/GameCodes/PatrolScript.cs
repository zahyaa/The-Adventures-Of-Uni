﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PatrolScript : MonoBehaviour {

     public Vector2 mov_vector;
     private Rigidbody2D rb2d;
     public float speed;
     public int damage;

     private Movescript MainCharacter;
     private GameObject go;

     // Use this for initialization
     void Start () {
          //Get and store a reference to the Rigidbody2D component so that we can access it.
          rb2d = GetComponent<Rigidbody2D>();
          // Freeze the rotation
          rb2d.freezeRotation = true;
          go = GameObject.Find("MainCharacter");
          MainCharacter = (Movescript)go.GetComponent(typeof(Movescript));
     }


	void FixedUpdate () {
          //Moves the Object
          rb2d.AddForce(mov_vector * speed);
     }
     void OnCollisionEnter2D(Collision2D col)
     {
          //Stops the object, then reverses the direction of the vector upon collision
          rb2d.velocity = Vector2.zero;
          mov_vector.x = mov_vector.x * -1;
          mov_vector.y = mov_vector.y * -1;

          //If this object collides with the maincharacter, it will decrement health equal to the damage variable
          if (col.gameObject.name == "MainCharacter")
          {
               for (int i = 0; i < damage; i++)
               {
                    MainCharacter.dec_health();
               }
          }
          if (col.gameObject.name == "Lazer(Clone)")
          {
            Destroy(this.gameObject);
          }
     }
}
