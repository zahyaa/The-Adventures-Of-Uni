﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {
    public Movescript mvs;

    public float runSpeed = 40f; //Character speed
    float horizontalMove = 0f;
    bool jump = false; //checks jumps
    bool crouch = false; //checks crounch, crouch variable is never used ignore, futher testing to commenece in the future

	// Update is called once per frame
	void Update () {
        horizontalMove = Input.GetAxisRaw("Horizontal") * runSpeed;

        if (Input.GetButtonDown("Jump"))
        {
            jump = true; // check the spacebar for input
        }
   

	}

    private void FixedUpdate()
    {
        mvs.Move(horizontalMove * Time.fixedDeltaTime, crouch, jump); // calculates moves, checks jumps and crouch
        jump = false; // jump is false if button is not activated
    }
}
