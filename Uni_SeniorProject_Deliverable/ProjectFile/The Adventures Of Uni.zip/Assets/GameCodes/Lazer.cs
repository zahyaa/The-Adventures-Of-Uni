using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lazer : MonoBehaviour {

	public float speed =5f;
	public int damage = 40;
	public Rigidbody2D rb;
	public GameObject impactEffect;

	private GameObject go;
	//private Enemy enemy;

	// Use this for initialization
	void Start () {
			rb.velocity = transform.right * speed;
	}

// changed from trigger
  void OnCollisionEnter2D ( Collision2D col ) {
		//Instantiate ( impactEffect, transform.position, transform.rotation );
		//Destroy(this.gameObject);
		if ( col.gameObject.name != "MainCharacter" ){

			Destroy( this.gameObject );

		}
	}

}
