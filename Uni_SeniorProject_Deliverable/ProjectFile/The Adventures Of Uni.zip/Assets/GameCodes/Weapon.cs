﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : MonoBehaviour {

	public Transform firePoint;
	public GameObject LazerPrefab;

	// Update is called once per frame
	void Update () {

		if ( Input.GetButtonDown( "Fire1") )
		{
			Shoot();
		}

	}

	void Shoot ()
	{
		// shooting logic
		var clone = Instantiate( LazerPrefab, firePoint.position, firePoint.rotation );

		Destroy ( clone.gameObject, 3 );		// destroys the lazer after 3 seconds
	}
}
